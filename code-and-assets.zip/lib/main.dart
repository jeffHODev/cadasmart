import 'package:blocks_app/misc/local_constants.dart';
import 'package:blocks_app/pages/program_entry.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:orientation/orientation.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Blocks App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      debugShowCheckedModeBanner: false,
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatelessWidget {
  final title;

  MyHomePage({Key key, this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIOverlays([]).then((_) {
      appInitialize(context);
      OrientationPlugin.forceOrientation(DeviceOrientation.landscapeRight);
    });
    ScreenUtil.init(context, designSize: Size(1334, 750));
    return Container(
        color: Colors.lightBlue,
        child: Center(
          child: ProgramEntry(),
        ));
  }
}
